A Pen created at CodePen.io. You can find this one at https://codepen.io/og-garrett-harmon/pen/wErpmd.

 Author: Garrett Harmon
Date Created: Sept 6 2018